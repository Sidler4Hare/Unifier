"""Rootless Podman adapter for project-owned environments.

Every start, exec, stop and remove addresses one container by exact name and
refuses the call unless that container carries this project's environment
labels. There is no name-prefix or "all containers" operation.
"""

from dataclasses import dataclass
import json
import os
from pathlib import Path
import re
import secrets
import select
import signal
import subprocess
import time

from multilinux.errors import MultilinuxError
from multilinux.share_label import PRESERVE_HOST, volume_options


LABEL_PROJECT = "multilinux.project"
LABEL_ENV = "multilinux.env"
LABEL_ROLE = "multilinux.role"
ROLE_ENVIRONMENT = "environment"

# Exec-form entrypoint is not resolved through PATH. It runs under --init
# (catatonit) so a stop signal reaches it without waiting out the stop timeout.
SLEEPER = "/usr/bin/sleep"


@dataclass(frozen=True)
class CreateSpec:
    name: str
    env_id: str
    project: str
    image: str
    mounts: tuple[tuple[str, str], ...]
    # Ordinary shared host directories default to preserving host labels.
    # "shared-relabel" is the explicit, historical :z request.
    share_label_policy: str = PRESERVE_HOST
    network: str = "none"
    # Session sockets are mounted without a relabel. :z would change the
    # compositor's own label on the host.
    session_mounts: tuple[tuple[str, str], ...] = ()
    selinux_label: str = "default"
    user_namespace: str = "rootless-default"
    devices: tuple[str, ...] = ()
    ipc: str = "private"


@dataclass(frozen=True)
class ContainerState:
    name: str
    container_id: str
    running: bool
    status: str
    project: str
    env_id: str
    role: str
    image: str
    pid: int | None
    started_at: str | None
    finished_at: str | None
    oom_killed: bool | None
    exit_code: int | None
    conmon_pid: int | None = None


@dataclass(frozen=True)
class ExecResult:
    returncode: int
    stdout: str
    stderr: str


@dataclass(frozen=True)
class GuestProcess:
    """Identity of the process actually running inside the container.

    A host ``podman exec`` process is only a proxy.  Its pid therefore never
    identifies the execution: the guest reports its own pid, kernel start time
    and session/process-group ids over a dedicated control fd before it execs
    the requested argv.  PID plus start time cannot be recycled by a later
    guest process.
    """
    pid: int
    start: int
    pgrp: int
    sid: int
    token: str


CONTROL_FD = 3
CONTROL_READY_SECONDS = 15.0
# Fixed guest shell programs.  They use only /bin/sh and /proc; no host helper
# binary, interpreter or ABI is assumed to work inside the guest.
GUEST_WRAPPER = r'''
set -u
token=$1
control_fd=$2
shift 2
case $control_fd in
    ''|*[!0-9]*) exit 125 ;;
esac
if [ ! -r /proc/$$/stat ]; then
    printf 'ERROR proc-unavailable\n' >&"$control_fd"
    exit 125
fi
if ! read -r _ml_pid _ml_comm _ml_state _ml_ppid _ml_pgrp _ml_sid _ml_tty \
        _ml_tpgid _ml_flags _ml_minflt _ml_cminflt _ml_majflt _ml_cmajflt \
        _ml_utime _ml_stime _ml_cutime _ml_cstime _ml_priority _ml_nice \
        _ml_nthreads _ml_itreal _ml_start _ml_rest < /proc/$$/stat; then
    printf 'ERROR stat-unreadable\n' >&"$control_fd"
    exit 125
fi
case $_ml_start in
    ''|*[!0-9]*) printf 'ERROR stat-unparsed\n' >&"$control_fd"; exit 125 ;;
esac
case $_ml_pgrp in
    ''|*[!0-9]*) printf 'ERROR pgrp-unparsed\n' >&"$control_fd"; exit 125 ;;
esac
case $_ml_sid in
    ''|*[!0-9]*) printf 'ERROR sid-unparsed\n' >&"$control_fd"; exit 125 ;;
esac
printf 'READY pid=%s start=%s pgrp=%s sid=%s token=%s\n' \
    "$$" "$_ml_start" "$_ml_pgrp" "$_ml_sid" "$token" >&"$control_fd" || exit 125
eval "exec $control_fd>&-"
exec "$@"
'''

GUEST_SETSID_BOOTSTRAP = r'''
set -u
wrapper=$1
token=$2
control_fd=$3
shift 3
for candidate in /usr/bin/setsid /usr/sbin/setsid /bin/setsid \
        /usr/local/bin/setsid /usr/local/sbin/setsid; do
    if [ -x "$candidate" ] && "$candidate" --wait true >/dev/null 2>&1; then
        # --wait is essential: if setsid has to fork, its parent must stay the
        # process podman tracks until the real session leader exits.
        exec "$candidate" --wait /bin/sh -c "$wrapper" ml-session \
            "$token" "$control_fd" "$@"
    fi
done
printf 'ERROR setsid-wait-unavailable\n' >&"$control_fd"
exit 125
'''

GUEST_PROBE = r'''
pid=$1
want=$2
path=/proc/$pid/stat
if [ ! -e "$path" ]; then printf 'GONE\n'; exit 0; fi
if [ ! -r "$path" ]; then printf 'UNKNOWN\n'; exit 0; fi
if ! IFS= read -r line < "$path" 2>/dev/null; then printf 'UNKNOWN\n'; exit 0; fi
line=${line##*)}
set -- $line
state=${1:-}
start=${20:-}
if [ -z "$start" ]; then printf 'UNKNOWN\n'; exit 0; fi
if [ "$start" != "$want" ]; then printf 'REPLACED\n'; exit 0; fi
if [ "$state" = Z ]; then printf 'GONE\n'; else printf 'ALIVE\n'; fi
'''

GUEST_SIGNAL = r'''
target_pid=$1
target_start=$2
target_signal=$3
target_mode=$4
path=/proc/$target_pid/stat
if [ ! -e "$path" ]; then printf 'GONE\n'; exit 0; fi
if [ ! -r "$path" ]; then printf 'UNKNOWN\n'; exit 0; fi
if ! IFS= read -r line < "$path" 2>/dev/null; then printf 'UNKNOWN\n'; exit 0; fi
line=${line##*)}
set -- $line
state=${1:-}
pgrp=${3:-}
sid=${4:-}
start=${20:-}
if [ -z "$start" ]; then printf 'UNKNOWN\n'; exit 0; fi
if [ "$start" != "$target_start" ]; then printf 'REPLACED\n'; exit 0; fi
if [ "$state" = Z ]; then printf 'GONE\n'; exit 0; fi
if [ "$target_mode" = session ] && [ "$sid" = "$target_pid" ] && [ "$target_pid" -gt 1 ]; then
    # Every process in this exec's own session belongs to this execution,
    # including background jobs from a shell.  Never touch another session.
    for directory in /proc/[0-9]*; do
        member=${directory##*/}
        [ "$member" = "$$" ] && continue
        [ -r "$directory/stat" ] || continue
        if ! IFS= read -r member_line < "$directory/stat" 2>/dev/null; then continue; fi
        member_line=${member_line##*)}
        set -- $member_line
        member_state=${1:-}
        member_sid=${4:-}
        [ "$member_sid" = "$target_pid" ] || continue
        [ "$member_state" = Z ] && continue
        kill -s "$target_signal" "$member" 2>/dev/null || true
    done
elif [ "$target_mode" = group ] && [ "$pgrp" = "$target_pid" ] && [ "$target_pid" -gt 1 ]; then
    kill -s "$target_signal" -- "-$target_pid" 2>/dev/null || exit 6
else
    kill -s "$target_signal" "$target_pid" 2>/dev/null || exit 6
fi
printf 'SIGNALLED\n'
'''

GUEST_CLEANUP = r'''
target=$1
mode=${2:-session}
[ "$target" -gt 1 ] 2>/dev/null || { printf 'UNSUPPORTED\n'; exit 2; }
case $mode in
    session|group) ;;
    *) printf 'UNSUPPORTED\n'; exit 2 ;;
esac
session_members() {
    for directory in /proc/[0-9]*; do
        member=${directory##*/}
        [ "$member" = "$$" ] && continue
        [ -r "$directory/stat" ] || continue
        if ! IFS= read -r line < "$directory/stat" 2>/dev/null; then continue; fi
        line=${line##*)}
        set -- $line
        state=${1:-}
        pgrp=${3:-}
        sid=${4:-}
        if [ "$mode" = group ]; then
            [ "$pgrp" = "$target" ] || continue
        else
            [ "$sid" = "$target" ] || continue
        fi
        [ "$state" = Z ] && continue
        printf '%s\n' "$member"
    done
}
remaining=$(session_members)
if [ -n "$remaining" ]; then
    for member in $remaining; do
        kill -s TERM "$member" 2>/dev/null || true
    done
    sleep 1
    remaining=$(session_members)
    if [ -n "$remaining" ]; then
        for member in $remaining; do
            kill -s KILL "$member" 2>/dev/null || true
        done
        sleep 1
        remaining=$(session_members)
    fi
fi
if [ -n "$remaining" ]; then
    printf 'SURVIVORS\n'
else
    printf 'CLEANED\n'
fi
'''


def project_token(project_root: Path) -> str:
    import hashlib
    return hashlib.sha256(str(project_root.resolve()).encode()).hexdigest()[:8]


def container_name(project_root: Path, env_id: str) -> str:
    return f"ml-{project_token(project_root)}-{env_id}"


def project_label(project_root: Path) -> str:
    return str(project_root.resolve())


def creation_argv(spec: CreateSpec) -> list[str]:
    """Create a stopped, writable environment.

    Rootless Podman's default user namespace maps container root to the host
    user, so files this environment creates on a shared mount are owned by
    that user. Optional keep-id maps the host UID/GID to themselves for GUI
    applications. Its package commands still run as container root, which
    maps to a subordinate host UID.

    The root is writable because native package transactions change it.
    Network is chosen here: none has no repository access, pasta does.

    The container runs with --init so PID 1 is a real init. Without it the
    sleeper never handles SIGTERM (podman stop then waits the whole timeout and
    the stop path blocks the next start) and orphaned exec children stay as
    zombies under PID 1. With it, stop signals are forwarded and orphans are
    reaped inside the container.
    """
    if "@sha256:" not in spec.image:
        raise MultilinuxError(f"refusing to create from an unlocked image reference: {spec.image}")
    if spec.network not in {"none", "pasta"}:
        raise MultilinuxError("environment network must be none or pasta")
    if spec.selinux_label not in {"default", "disable"}:
        raise MultilinuxError("selinux label must be default or disable")
    if spec.ipc not in {"private", "host"}:
        raise MultilinuxError("ipc mode must be private or host")
    if spec.user_namespace not in {"rootless-default", "keep-id"}:
        raise MultilinuxError("user namespace must be rootless-default or keep-id")
    share_options = volume_options(spec.share_label_policy)
    argv = [
        "podman", "create",
        "--name", spec.name,
        "--label", f"{LABEL_PROJECT}={spec.project}",
        "--label", f"{LABEL_ENV}={spec.env_id}",
        "--label", f"{LABEL_ROLE}={ROLE_ENVIRONMENT}",
        "--pull=never",
        "--network=" + spec.network,
        "--http-proxy=false",
        "--restart=no",
        "--init",
        "--stop-timeout=8",
        "--entrypoint", SLEEPER,
    ]
    if spec.ipc == "host":
        argv.append("--ipc=host")
    if spec.user_namespace == "keep-id":
        argv.extend(["--userns=keep-id", "--user", "0", "--passwd-entry",
                     "$USERNAME:*:$UID:$GID:$NAME:/home/multilinux-$UID:/bin/sh"])
    for device in spec.devices:
        if not re.fullmatch(r"(/dev/video[0-9]+|/dev/dri/(card|renderD)[0-9]+)", device):
            raise MultilinuxError("desktop device must be an explicit /dev/videoN camera or /dev/dri device")
        argv.extend(["--device", f"{device}:{device}:rw"])
    for host, container in spec.mounts:
        volume = f"{host}:{container}"
        if share_options:
            volume += ":" + share_options
        argv.extend(["--volume", volume])
    for host, container in spec.session_mounts:
        if ":" in host or ":" in container:
            raise MultilinuxError("session mount paths cannot contain ':'")
        argv.extend(["--volume", f"{host}:{container}"])
    if spec.selinux_label == "disable":
        argv.extend(["--security-opt", "label=disable"])
    argv.extend([spec.image, "infinity"])
    return argv


def exec_argv(name: str, argv: list[str], *, workdir: str | None, env: dict[str, str],
              user: str | None = None, interactive: bool = False,
              tty: bool = False, preserve_fd: int | None = None) -> list[str]:
    """Exec argv directly. Only the allowlisted variables are passed through.

    ``-i`` keeps stdin connected for pipes. ``-t`` is deliberately separate:
    podman merges stdout/stderr and can hang a pipe when a TTY is allocated, so
    callers must request it only for a real interactive terminal.
    ``preserve_fd`` keeps a host control descriptor open in the guest without
    mixing it into stdout or stderr; stdout/stderr stay separate.
    """
    if not argv:
        raise MultilinuxError("argv is empty")
    command = ["podman", "exec"]
    if interactive or tty:
        command.append("-i")
    if tty:
        command.append("-t")
    if user is not None:
        command.extend(["--user", user])
    if preserve_fd is not None:
        if isinstance(preserve_fd, bool) or not isinstance(preserve_fd, int) or preserve_fd < 3:
            raise MultilinuxError("preserved control descriptor must be an integer >= 3")
        command.extend(["--preserve-fd", str(preserve_fd)])
    if workdir is not None:
        command.extend(["--workdir", workdir])
    for key, value in env.items():
        command.extend(["--env", f"{key}={value}"])
    command.append(name)
    command.extend(argv)
    return command


def guest_session_argv(argv: list[str], *, token: str, control_fd: int,
                        tty: bool) -> list[str]:
    """Build the fixed guest wrapper that reports real execution identity.

    A non-TTY execution gets its own session through ``setsid --wait`` so the
    whole command tree can be signalled and cleaned without touching other
    sessions in the shared container.  A requested TTY must keep the podman pty
    as its controlling terminal, so the wrapper only records the ids the guest
    kernel assigned and execs the argv unchanged.
    """
    if not argv:
        raise MultilinuxError("guest session argv is empty")
    if not isinstance(token, str) or not re.fullmatch(r"[0-9a-f]{32}", token):
        raise MultilinuxError("guest session token is malformed")
    if isinstance(control_fd, bool) or not isinstance(control_fd, int) or control_fd < 3:
        raise MultilinuxError("guest control descriptor must be an integer >= 3")
    inner = ["/bin/sh", "-c", GUEST_WRAPPER, "ml-session", token,
             str(control_fd), *argv]
    if tty:
        return inner
    return ["/bin/sh", "-c", GUEST_SETSID_BOOTSTRAP, "ml-session",
            GUEST_WRAPPER, token, str(control_fd), *argv]


def _host_exit_status(code: int) -> int:
    return code if code >= 0 else 128 - code


def parse_guest_ready(line: str, token: str) -> GuestProcess:
    if not isinstance(line, str) or not line.endswith("\n"):
        raise MultilinuxError("guest execution did not report a complete identity line")
    parts = line.split()
    if not parts or parts[0] != "READY":
        raise MultilinuxError(
            "guest execution identity was not reported; refusing an untracked execution")
    values = {}
    for item in parts[1:]:
        if "=" not in item:
            raise MultilinuxError("guest execution identity line is malformed")
        key, value = item.split("=", 1)
        values[key] = value
    if values.get("token") != token:
        raise MultilinuxError("guest execution identity token mismatch")
    parsed = {}
    for key in ("pid", "start", "pgrp", "sid"):
        try:
            number = int(values[key], 10)
        except (KeyError, ValueError) as exc:
            raise MultilinuxError(
                f"guest execution identity has no valid {key}") from exc
        if number <= 0:
            raise MultilinuxError(f"guest execution identity has invalid {key}")
        parsed[key] = number
    if parsed["pid"] == 1:
        raise MultilinuxError("guest execution cannot use container PID 1")
    return GuestProcess(pid=parsed["pid"], start=parsed["start"],
                        pgrp=parsed["pgrp"], sid=parsed["sid"], token=token)


class SessionExecution:
    """One live guest execution and the host proxy that carries its streams."""

    def __init__(self, runtime: "PodmanRuntime", *, name: str, project: str,
                 env_id: str, process, guest: GuestProcess,
                 user: str | None = None):
        self.runtime = runtime
        self.name = name
        self.project = project
        self.env_id = env_id
        self.process = process
        self.guest = guest
        self.user = user

    def poll(self):
        return self.process.poll()

    def wait(self, timeout=None):
        return self.process.wait(timeout=timeout)

    def probe(self) -> str:
        return self.runtime.probe_guest(
            self.name, self.guest, project=self.project, env_id=self.env_id,
            user=self.user)

    def signal(self, signum) -> str:
        return self.runtime.signal_guest(
            self.name, self.guest, signum, project=self.project, env_id=self.env_id,
            user=self.user)

    def cleanup(self) -> str:
        return self.runtime.cleanup_guest(
            self.name, self.guest, project=self.project, env_id=self.env_id,
            user=self.user)

    def abort_proxy(self) -> None:
        """Abort only the host proxy when the guest cannot be signalled.

        This is never treated as guest cancellation by ProjectSessions.
        """
        self.runtime._kill_proxy_group(self.process)


def container_state_from_inspect(name: str, data: dict) -> ContainerState:
    labels = (data.get("Config") or {}).get("Labels") or {}
    state = data.get("State") or {}
    return ContainerState(
        name=name,
        container_id=data.get("Id") or "",
        running=bool(state.get("Running")),
        status=state.get("Status") or "unknown",
        project=labels.get(LABEL_PROJECT, ""),
        env_id=labels.get(LABEL_ENV, ""),
        role=labels.get(LABEL_ROLE, ""),
        image=data.get("ImageName") or data.get("Image") or "",
        pid=state.get("Pid"),
        started_at=state.get("StartedAt"),
        finished_at=state.get("FinishedAt"),
        oom_killed=state.get("OOMKilled"),
        exit_code=state.get("ExitCode"),
        conmon_pid=state.get("ConmonPid") or None,
    )


class PodmanRuntime:
    def __init__(self, runner=None, *, check_rootless=True, popen=None):
        self.runner = runner or _run_podman
        self.popen = popen or subprocess.Popen
        self.check_rootless = check_rootless
        self._rootless_ok = False

    def create(self, spec: CreateSpec) -> str:
        self._ensure_rootless()
        if self.inspect(spec.name) is not None:
            raise MultilinuxError(f"container {spec.name} already exists")
        result = self.runner(creation_argv(spec), capture=True, timeout=60)
        if result.returncode:
            raise MultilinuxError(f"podman create failed: {(result.stderr or '')[-2000:]}")
        container_id = (result.stdout or "").strip()
        if not container_id:
            raise MultilinuxError("podman create did not return a container id")
        return container_id

    def inspect(self, name: str) -> ContainerState | None:
        self._ensure_rootless()
        result = self.runner(["podman", "inspect", "--format", "json", name],
                             capture=True, timeout=20)
        if result.returncode:
            detail = (result.stderr or "") + (result.stdout or "")
            if "no such" in detail.lower():
                return None
            raise MultilinuxError(f"podman inspect failed: {detail[-1500:]}")
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise MultilinuxError(f"podman inspect returned invalid JSON: {exc}") from exc
        if not payload:
            return None
        return container_state_from_inspect(name, payload[0])

    def start(self, name: str, *, project: str, env_id: str) -> None:
        self._require_owned(name, project, env_id)
        self._check(["podman", "start", name], timeout=40, action="start")

    def stop(self, name: str, *, project: str, env_id: str) -> None:
        self._require_owned(name, project, env_id)
        self._check(["podman", "stop", "--time", "8", name], timeout=30, action="stop")

    def remove(self, name: str, *, project: str, env_id: str) -> None:
        self._require_owned(name, project, env_id)
        self._check(["podman", "rm", "--force", name], timeout=40, action="remove")

    def copy_in(self, name: str, host_path: str, container_path: str, *, project: str, env_id: str) -> None:
        self._require_owned(name, project, env_id)
        self._check(["podman", "cp", "--pause=false", host_path, f"{name}:{container_path}"],
                    timeout=60, action="cp")

    def container_size(self, name: str, *, project: str, env_id: str) -> dict:
        """Writable layer and whole-root size as reported by Podman.

        SizeRootFs includes shared lower layers, so it is not exclusive space.
        """
        self._require_owned(name, project, env_id)
        result = self.runner(
            ["podman", "container", "inspect", "--size", "--format", "{{json .}}", name],
            capture=True, timeout=120)
        if result.returncode:
            detail = ((result.stderr or "") + (result.stdout or ""))[-2000:]
            raise MultilinuxError(f"podman container inspect --size failed: {detail}")
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise MultilinuxError(f"podman size inspect returned invalid JSON: {exc}") from exc
        return {
            "size_rw_bytes": payload.get("SizeRw"),
            "size_root_fs_bytes": payload.get("SizeRootFs"),
        }

    def image_info(self, reference: str) -> dict:
        if "@sha256:" not in reference:
            raise MultilinuxError(f"refusing to inspect an unlocked image reference: {reference}")
        result = self.runner(
            ["podman", "image", "inspect", "--format", "{{json .}}", reference],
            capture=True, timeout=60)
        if result.returncode:
            detail = ((result.stderr or "") + (result.stdout or ""))[-2000:]
            raise MultilinuxError(f"podman image inspect failed: {detail}")
        try:
            payload = json.loads(result.stdout)
        except json.JSONDecodeError as exc:
            raise MultilinuxError(f"podman image inspect returned invalid JSON: {exc}") from exc
        return {
            "id": payload.get("Id"),
            "digest": payload.get("Digest"),
            "size_bytes": payload.get("Size"),
        }

    def exec(self, name: str, argv: list[str], *, project: str, env_id: str,
             workdir: str | None, env: dict[str, str], capture: bool, timeout: int | None,
             user: str | None = None) -> ExecResult:
        self._require_owned(name, project, env_id)
        result = self.runner(exec_argv(name, argv, workdir=workdir, env=env, user=user),
                             capture=capture, timeout=timeout)
        return ExecResult(result.returncode, result.stdout or "", result.stderr or "")

    def start_session_exec(self, name: str, argv: list[str], *, project: str,
                           env_id: str, workdir: str | None, env: dict[str, str],
                           user: str | None = None, interactive: bool = True,
                           tty: bool = False, on_spawn=None,
                           control_timeout: float = CONTROL_READY_SECONDS
                           ) -> SessionExecution:
        """Start one exec and require a real guest identity before returning.

        No session is handed to a supervisor until the guest has reported its
        pid, start time, process group and session over the dedicated control
        fd. A proxy alone is not an execution identity. If readiness is not
        proven, the proxy is killed and the call fails closed;
        ProjectSessions keeps the lease unresolved instead of claiming a clean
        cancellation it cannot prove.
        """
        self._require_owned(name, project, env_id)
        token = secrets.token_hex(16)
        read_fd, write_fd = os.pipe()
        process = None
        try:
            os.set_inheritable(write_fd, True)
            guest = guest_session_argv(argv, token=token, control_fd=write_fd,
                                       tty=tty)
            command = exec_argv(name, guest, workdir=workdir, env=env,
                                user=user, interactive=interactive, tty=tty,
                                preserve_fd=write_fd)
            try:
                process = self.popen(
                    command, stdin=None, stdout=None, stderr=None,
                    process_group=0, pass_fds=(write_fd,))
            except (OSError, ValueError) as exc:
                raise MultilinuxError(f"cannot start podman exec: {exc}") from exc
        except BaseException:
            if process is None:
                os.close(read_fd)
            raise
        finally:
            os.close(write_fd)
        if on_spawn is not None:
            on_spawn(process)
        try:
            identity = self._read_guest_identity(read_fd, token, control_timeout)
        except BaseException:
            self._kill_proxy_group(process)
            os.close(read_fd)
            raise
        os.close(read_fd)
        return SessionExecution(self, name=name, project=project, env_id=env_id,
                                process=process, guest=identity, user=user)

    def _read_guest_identity(self, read_fd: int, token: str,
                             timeout: float) -> GuestProcess:
        deadline = time.monotonic() + timeout
        data = b""
        while b"\n" not in data:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise MultilinuxError(
                    "guest execution did not report its identity in time; "
                    "refusing to claim an untracked execution was cancelled")
            readable, _writable, _errors = select.select([read_fd], [], [], remaining)
            if not readable:
                raise MultilinuxError(
                    "guest execution identity channel timed out before readiness")
            chunk = os.read(read_fd, 4096)
            if not chunk:
                break
            data += chunk
            if len(data) > 4096:
                raise MultilinuxError("guest execution identity line is too long")
        if b"\n" not in data:
            raise MultilinuxError(
                "guest execution exited before reporting its identity")
        line = data.split(b"\n", 1)[0].decode("utf-8", "replace")
        if line.startswith("ERROR"):
            raise MultilinuxError(f"guest prerequisite failed: {line}")
        return parse_guest_ready(line + "\n", token)

    @staticmethod
    def _kill_proxy_group(process) -> None:
        """Kill only the host proxy group after readiness failed.

        This does not pretend the guest stopped; callers must keep the
        resolution unresolved when no guest identity exists.
        """
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except OSError:
            try:
                process.kill()
            except OSError:
                pass
        try:
            process.wait(timeout=5)
        except (subprocess.TimeoutExpired, OSError, ValueError):
            pass

    def session_exec(self, name: str, argv: list[str], *, project: str, env_id: str,
                     workdir: str | None, env: dict[str, str],
                     user: str | None = None, interactive: bool = True,
                     tty: bool = False, on_spawn=None, on_guest=None) -> int:
        """Compatibility wrapper for a foreground execution with guest control."""
        execution = self.start_session_exec(
            name, argv, project=project, env_id=env_id, workdir=workdir,
            env=env, user=user, interactive=interactive, tty=tty,
            on_spawn=on_spawn)
        if on_guest is not None:
            on_guest(execution.guest)
        try:
            code = execution.wait()
        except (OSError, ValueError) as exc:
            raise MultilinuxError(f"cannot wait for podman exec: {exc}") from exc
        return _host_exit_status(code)

    def probe_guest(self, name: str, guest: GuestProcess, *, project: str,
                    env_id: str, user: str | None = None, timeout: int = 10) -> str:
        """Return alive/gone/unknown using the guest's own /proc identity."""
        try:
            self._require_owned(name, project, env_id)
            result = self.runner(
                exec_argv(name, ["/bin/sh", "-c", GUEST_PROBE, "ml-probe",
                                 str(guest.pid), str(guest.start)],
                          workdir=None, env={}, user=user),
                capture=True, timeout=timeout)
        except (MultilinuxError, OSError, ValueError, subprocess.TimeoutExpired):
            return "unknown"
        if result.returncode:
            return "unknown"
        answer = (result.stdout or "").strip()
        if answer == "ALIVE":
            return "alive"
        if answer in {"GONE", "REPLACED"}:
            return "gone"
        return "unknown"

    def signal_guest(self, name: str, guest: GuestProcess, signum, *,
                     project: str, env_id: str, user: str | None = None,
                     timeout: int = 10) -> str:
        """Target the exact guest execution, never the host proxy or container."""
        try:
            signal_name = signal.Signals(signum).name
        except (ValueError, AttributeError) as exc:
            raise MultilinuxError(f"unsupported guest signal: {signum!r}") from exc
        if signal_name.startswith("SIG"):
            signal_name = signal_name[3:]
        mode = "session" if guest.sid == guest.pid and guest.pid > 1 else "group"
        if mode == "group" and not (guest.pgrp == guest.pid and guest.pid > 1):
            mode = "pid"
        try:
            self._require_owned(name, project, env_id)
            result = self.runner(
                exec_argv(name, ["/bin/sh", "-c", GUEST_SIGNAL, "ml-signal",
                                 str(guest.pid), str(guest.start), signal_name, mode],
                          workdir=None, env={}, user=user),
                capture=True, timeout=timeout)
        except (MultilinuxError, OSError, ValueError, subprocess.TimeoutExpired):
            return "unknown"
        answer = (result.stdout or "").strip()
        if answer == "SIGNALLED" and result.returncode == 0:
            return "signalled"
        if answer in {"GONE", "REPLACED"}:
            return "gone"
        return "unknown"

    def cleanup_guest(self, name: str, guest: GuestProcess, *, project: str,
                      env_id: str, user: str | None = None,
                      timeout: int = 15) -> str:
        """Clean only this execution's own guest session/group, then verify it."""
        if guest.sid == guest.pid and guest.pid > 1:
            mode = "session"
        elif guest.pgrp == guest.pid and guest.pid > 1:
            mode = "group"
        else:
            return "unsupported"
        try:
            self._require_owned(name, project, env_id)
            result = self.runner(
                exec_argv(name, ["/bin/sh", "-c", GUEST_CLEANUP, "ml-cleanup",
                                 str(guest.pid), mode],
                          workdir=None, env={}, user=user),
                capture=True, timeout=timeout)
        except (MultilinuxError, OSError, ValueError, subprocess.TimeoutExpired):
            return "unknown"
        if result.returncode != 0 or (result.stdout or "").strip() != "CLEANED":
            return "unknown"
        return self.probe_guest(name, guest, project=project, env_id=env_id,
                                user=user)

    def _require_owned(self, name: str, project: str, env_id: str) -> ContainerState:
        info = self.inspect(name)
        if info is None:
            raise MultilinuxError(f"container {name} does not exist")
        if info.project != project or info.env_id != env_id or info.role != ROLE_ENVIRONMENT:
            raise MultilinuxError(
                f"refusing to touch {name}: it is not environment {env_id} of this project")
        return info

    def _check(self, argv: list[str], *, timeout: int, action: str) -> None:
        result = self.runner(argv, capture=True, timeout=timeout)
        if result.returncode:
            detail = ((result.stderr or "") + (result.stdout or ""))[-2000:]
            raise MultilinuxError(f"podman {action} failed: {detail}")

    def _ensure_rootless(self) -> None:
        if not self.check_rootless or self._rootless_ok:
            return
        import sys
        root = Path(__file__).resolve().parents[2]
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        from tools import lab
        lab.require_rootless()
        self._rootless_ok = True


def decode_output(blob: bytes | str | None) -> str:
    """Podman and package tools sometimes emit bytes that are not UTF-8."""
    if blob is None:
        return ""
    if isinstance(blob, str):
        return blob
    return blob.decode("utf-8", errors="replace")


def _run_podman(argv: list[str], *, capture: bool, timeout: int | None):
    try:
        result = subprocess.run(argv, capture_output=capture, timeout=timeout, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise MultilinuxError(f"{argv[0]} failed: {exc}") from exc
    if capture:
        result.stdout = decode_output(result.stdout)
        result.stderr = decode_output(result.stderr)
    return result
