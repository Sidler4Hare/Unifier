# Unifier headless host validation

Current source snapshot for Linux x86_64, Python 3.11+, rootless Podman and cgroup v2.
See UBUNTU-SERVER.md for the Ubuntu Server procedure.
This archive contains no deployed applications, private HOME, runtime state or container images.
Run compat matrix, lab doctor, lab pull, then tools/probe_headless.py with a fresh --output.
A successful Fedora replay is not Ubuntu acceptance; run on the actual Ubuntu host.
